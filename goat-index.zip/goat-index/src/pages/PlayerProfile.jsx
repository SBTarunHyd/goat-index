import profiles from "../data/profiles.json";
import careerTotals from "../data/careerTotals.json";
import seasons from "../data/seasons.json";
import trophies from "../data/trophies.json";
import awards from "../data/awards.json";
import records from "../data/records.json";
import SeasonChart, { aggregateSeasons } from "../components/SeasonChart";
import TrophyTimeline, { buildTrophyTimeline } from "../components/TrophyTimeline";

export default function PlayerProfile({ playerName, accent }) {
  const profile = profiles.find((p) => p.Full_Name === playerName);
  const totals = careerTotals.find((c) => c.Player === playerName);
  const playerSeasons = seasons.filter((s) => s.Player === playerName);
  const trophyData = trophies.find((t) => t.Player === playerName);
  const awardData = awards.find((a) => a.Player === playerName);
  const playerRecords = records.filter((r) => r.Player === playerName);

  const seasonData = aggregateSeasons(playerSeasons);
  const timelineData = buildTrophyTimeline(trophyData.Trophies);

  const color = accent === "messi" ? "#5ec9f7" : "#ff4757";
  const textAccent = accent === "messi" ? "text-messi" : "text-ronaldo";
  const borderAccent = accent === "messi" ? "border-messi" : "border-ronaldo";

  return (
    <div className="mx-auto max-w-5xl px-5 pb-24 pt-16">
      {/* HEADER */}
      <div className={`card animate-fade-up border-t-4 ${borderAccent} p-8`}>
        <p className="text-xs uppercase tracking-widest text-white/40">{profile.Nationality}</p>
        <h1 className={`font-display text-6xl ${textAccent}`}>{profile.Full_Name}</h1>
        <p className="mt-2 text-white/60">
          {profile.Primary_Position} · {profile.Current_Club} · Born {profile.Date_of_Birth}
        </p>

        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
          <Stat label="Total Goals" value={totals.Total_Goals} />
          <Stat label="Total Assists" value={totals.Total_Assists} />
          <Stat label="Matches" value={totals.Total_Matches} />
          <Stat label="Trophies" value={trophyData.Total_Trophies} />
        </div>
      </div>

      {/* CAREER OVERVIEW */}
      <section className="mt-12">
        <h2 className="mb-4 font-display text-3xl text-white">Career Overview</h2>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <Stat label="Goals / Game" value={totals.Goals_per_Game} />
          <Stat label="Hat-tricks" value={totals.Hat_tricks} />
          <Stat label="Penalty Goals" value={totals.Penalty_Goals} />
          <Stat label="Free Kick Goals" value={totals.Free_Kick_Goals} />
          <Stat label="Ballon d'Or" value={awardData.Ballon_dOr} />
          <Stat label="Golden Boot" value={awardData.Golden_Boot} />
          <Stat label="League MVP" value={awardData.League_MVP} />
          <Stat label="Career Span" value={`${profile.Career_Span} yrs`} />
        </div>
      </section>

      {/* SEASON CHART */}
      <section className="mt-12">
        <h2 className="mb-4 font-display text-3xl text-white">Goals & Assists per Season</h2>
        <div className="card p-6">
          <SeasonChart data={seasonData} color={color} />
        </div>
      </section>

      {/* TROPHY TIMELINE */}
      <section className="mt-12">
        <h2 className="mb-4 font-display text-3xl text-white">Trophy Progression</h2>
        <div className="card p-6">
          <TrophyTimeline data={timelineData} color={color} label={accent} />
        </div>
      </section>

      {/* SEASON TABLE */}
      <section className="mt-12">
        <h2 className="mb-4 font-display text-3xl text-white">Season-by-Season</h2>
        <div className="card overflow-x-auto p-4">
          <table className="w-full min-w-[600px] text-left text-sm">
            <thead>
              <tr className="text-white/40">
                <th className="px-3 py-2">Season</th>
                <th className="px-3 py-2">Club</th>
                <th className="px-3 py-2">Competition</th>
                <th className="px-3 py-2">Matches</th>
                <th className="px-3 py-2">Goals</th>
                <th className="px-3 py-2">Assists</th>
              </tr>
            </thead>
            <tbody>
              {playerSeasons.map((s, i) => (
                <tr key={i} className="border-t border-white/5 text-white/70 hover:bg-white/5">
                  <td className="px-3 py-2 font-medium text-white">{s.Season}</td>
                  <td className="px-3 py-2">{s.Club}</td>
                  <td className="px-3 py-2">{s.Competition}</td>
                  <td className="px-3 py-2">{s.Matches}</td>
                  <td className={`px-3 py-2 font-semibold ${textAccent}`}>{s.Goals}</td>
                  <td className="px-3 py-2">{s.Assists}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* HIGHLIGHTS / RECORDS */}
      <section className="mt-12">
        <h2 className="mb-4 font-display text-3xl text-white">Key Highlights & Records</h2>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {playerRecords.map((r, i) => (
            <div key={i} className="card p-4">
              <p className="text-sm text-white/50">{r.Competition}</p>
              <p className="font-semibold text-white">{r.Record}</p>
              <p className={`text-2xl font-display ${textAccent}`}>{r.Value}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="rounded-xl bg-white/5 p-4 text-center">
      <p className="font-display text-2xl text-white">{value ?? "—"}</p>
      <p className="mt-1 text-xs uppercase tracking-wider text-white/40">{label}</p>
    </div>
  );
}
