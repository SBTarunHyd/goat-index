import { computeCategoryScores, computeGoatIndex } from "../lib/goatIndex";
import { CATEGORY_LABELS, GOAT_WEIGHTS } from "../lib/goatConfig";
import ScoreRing from "../components/ScoreRing";

export default function GoatIndexPage() {
  const categoryScores = computeCategoryScores();
  const { finalScores, winner } = computeGoatIndex();

  return (
    <div className="mx-auto max-w-4xl px-5 pb-24 pt-16">
      <div className="text-center animate-fade-up">
        <p className="text-xs uppercase tracking-widest text-goat">The Methodology</p>
        <h1 className="font-display text-5xl text-white sm:text-6xl">GOAT Index</h1>
        <p className="mx-auto mt-3 max-w-2xl text-white/50">
          A transparent, weighted scoring system out of 100. Each career category is scored
          relative to the two players, then combined using configurable weights — no hidden
          opinion, just the math.
        </p>
      </div>

      {/* FINAL SCORES */}
      <div className="card mt-10 grid grid-cols-1 gap-8 p-8 sm:grid-cols-3 sm:items-center">
        <ScoreRing score={finalScores["Lionel Messi"]} color="#5ec9f7" label="Lionel Messi" />
        <div className="text-center">
          <p className="text-xs uppercase tracking-widest text-white/40">Final Verdict</p>
          <p className={`mt-2 font-display text-3xl ${winner === "Lionel Messi" ? "text-messi" : "text-ronaldo"}`}>
            {winner} leads
          </p>
        </div>
        <ScoreRing score={finalScores["Cristiano Ronaldo"]} color="#ff4757" label="Cristiano Ronaldo" />
      </div>

      {/* WEIGHTS TABLE */}
      <section className="mt-14">
        <h2 className="mb-4 font-display text-3xl text-white">Scoring Weights</h2>
        <div className="card divide-y divide-white/5">
          {Object.entries(GOAT_WEIGHTS).map(([key, weight]) => {
            const scores = categoryScores[key];
            return (
              <div key={key} className="flex items-center justify-between gap-4 p-5">
                <div>
                  <p className="font-semibold text-white">{CATEGORY_LABELS[key]}</p>
                  <p className="text-xs text-white/40">
                    Messi {scores["Lionel Messi"].toFixed(1)} · Ronaldo {scores["Cristiano Ronaldo"].toFixed(1)}
                  </p>
                </div>
                <span className="rounded-full bg-goat/15 px-4 py-1.5 text-sm font-bold text-goat">
                  {weight}%
                </span>
              </div>
            );
          })}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="mt-14">
        <h2 className="mb-4 font-display text-3xl text-white">How It's Calculated</h2>
        <div className="card space-y-4 p-6 text-sm leading-relaxed text-white/60">
          <p>
            <span className="font-semibold text-white">1. Category scoring.</span> For each
            category (goals, assists, trophies, big-game performance, consistency, awards),
            multiple underlying metrics are pulled from the dataset and converted to a relative
            0–100 split between the two players.
          </p>
          <p>
            <span className="font-semibold text-white">2. Weighting.</span> Each category score
            is multiplied by its configured weight (see table above). Weights are defined in a
            single config file (<code className="rounded bg-white/10 px-1.5 py-0.5">src/lib/goatConfig.js</code>)
            and sum to 100.
          </p>
          <p>
            <span className="font-semibold text-white">3. Final score.</span> Weighted category
            scores are summed to produce each player's final GOAT Index score out of 100.
          </p>
          <p className="text-white/40">
            Want different priorities? Adjust the weights in the config file — every chart and
            score on this site recalculates automatically.
          </p>
        </div>
      </section>
    </div>
  );
}
