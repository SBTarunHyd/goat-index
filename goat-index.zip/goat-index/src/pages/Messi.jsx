import PlayerProfile from "./PlayerProfile";

export default function Messi() {
  return <PlayerProfile playerName="Lionel Messi" accent="messi" />;
}
