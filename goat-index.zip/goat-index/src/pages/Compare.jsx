import { computeCategoryScores, computeGoatIndex } from "../lib/goatIndex";
import { CATEGORY_LABELS, GOAT_WEIGHTS } from "../lib/goatConfig";
import careerTotals from "../data/careerTotals.json";
import trophies from "../data/trophies.json";
import international from "../data/international.json";
import RadarComparison from "../components/RadarComparison";
import CategoryCard from "../components/CategoryCard";
import StatBar from "../components/StatBar";

const CATEGORY_DESCRIPTIONS = {
  goals: "Total goals, goals-per-game rate, and club goal output.",
  assists: "Total assists and overall goal contributions.",
  trophies: "Total trophies won, weighted toward major honors.",
  bigGames: "Champions League semifinal/final and cup-final output.",
  consistency: "Career longevity, availability, and scoring efficiency.",
  awards: "Ballon d'Or, FIFA Best, Golden Boot, and league MVP awards.",
};

export default function Compare() {
  const categoryScores = computeCategoryScores();
  const { finalScores, winner } = computeGoatIndex();
  const messiTotals = careerTotals.find((c) => c.Player === "Lionel Messi");
  const ronaldoTotals = careerTotals.find((c) => c.Player === "Cristiano Ronaldo");
  const messiTrophies = trophies.find((t) => t.Player === "Lionel Messi");
  const ronaldoTrophies = trophies.find((t) => t.Player === "Cristiano Ronaldo");
  const messiIntl = international.find((i) => i.Player === "Lionel Messi");
  const ronaldoIntl = international.find((i) => i.Player === "Cristiano Ronaldo");

  return (
    <div className="mx-auto max-w-5xl px-5 pb-24 pt-16">
      <div className="text-center animate-fade-up">
        <p className="text-xs uppercase tracking-widest text-goat">Category by Category</p>
        <h1 className="font-display text-5xl text-white sm:text-6xl">Head-to-Head</h1>
        <p className="mx-auto mt-3 max-w-xl text-white/50">
          Overall GOAT Index leader:{" "}
          <span className={winner === "Lionel Messi" ? "text-messi font-bold" : "text-ronaldo font-bold"}>
            {winner}
          </span>{" "}
          ({finalScores["Lionel Messi"]} vs {finalScores["Cristiano Ronaldo"]})
        </p>
      </div>

      {/* RADAR */}
      <div className="card mt-10 p-6">
        <RadarComparison categoryScores={categoryScores} />
      </div>

      {/* RAW STATS */}
      <section className="mt-14">
        <h2 className="mb-4 font-display text-3xl text-white">Raw Numbers</h2>
        <div className="card p-6">
          <StatBar label="Total Goals" messiValue={messiTotals.Total_Goals} ronaldoValue={ronaldoTotals.Total_Goals} />
          <StatBar label="Total Assists" messiValue={messiTotals.Total_Assists} ronaldoValue={ronaldoTotals.Total_Assists} />
          <StatBar label="Career Trophies" messiValue={messiTrophies.Total_Trophies} ronaldoValue={ronaldoTrophies.Total_Trophies} />
          <StatBar label="Int'l Goals" messiValue={messiIntl.Goals} ronaldoValue={ronaldoIntl.Goals} />
          <StatBar label="Int'l Assists" messiValue={messiIntl.Assists} ronaldoValue={ronaldoIntl.Assists} />
          <StatBar label="Hat-tricks" messiValue={messiTotals.Hat_tricks} ronaldoValue={ronaldoTotals.Hat_tricks} />
        </div>
      </section>

      {/* CATEGORY CARDS */}
      <section className="mt-14">
        <h2 className="mb-4 font-display text-3xl text-white">Weighted Category Breakdown</h2>
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          {Object.entries(categoryScores).map(([key, scores]) => (
            <CategoryCard
              key={key}
              title={CATEGORY_LABELS[key]}
              messiScore={scores["Lionel Messi"]}
              ronaldoScore={scores["Cristiano Ronaldo"]}
              weight={GOAT_WEIGHTS[key]}
              description={CATEGORY_DESCRIPTIONS[key]}
            />
          ))}
        </div>
      </section>
    </div>
  );
}
