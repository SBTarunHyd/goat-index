import { Link } from "react-router-dom";
import { computeGoatIndex } from "../lib/goatIndex";
import careerTotals from "../data/careerTotals.json";
import trophies from "../data/trophies.json";
import ScoreRing from "../components/ScoreRing";
import StatBar from "../components/StatBar";

export default function Home() {
  const { finalScores, winner } = computeGoatIndex();
  const messi = careerTotals.find((c) => c.Player === "Lionel Messi");
  const ronaldo = careerTotals.find((c) => c.Player === "Cristiano Ronaldo");
  const messiTrophies = trophies.find((t) => t.Player === "Lionel Messi").Total_Trophies;
  const ronaldoTrophies = trophies.find((t) => t.Player === "Cristiano Ronaldo").Total_Trophies;

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden px-5 pb-16 pt-20 md:pt-28">
        <div className="mx-auto max-w-5xl text-center">
          <p className="mb-4 text-sm font-semibold uppercase tracking-[0.3em] text-goat animate-fade-up">
            The Data-Driven Debate
          </p>
          <h1 className="font-display text-6xl leading-none text-white sm:text-8xl animate-fade-up">
            <span className="text-messi">MESSI</span>{" "}
            <span className="text-white/30">vs</span>{" "}
            <span className="text-ronaldo">RONALDO</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-balance text-white/60 animate-fade-up">
            Every goal, trophy, and record — weighed, scored, and settled by the numbers.
            Explore the full GOAT Index, tuned from a transparent, configurable scoring model.
          </p>

          <div className="mt-8 flex flex-wrap justify-center gap-3 animate-fade-up">
            <Link
              to="/compare"
              className="rounded-full bg-white px-6 py-3 text-sm font-semibold text-ink transition hover:bg-white/90"
            >
              Head-to-Head Comparison
            </Link>
            <Link
              to="/goat-index"
              className="rounded-full border border-white/15 px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/5"
            >
              See Full GOAT Index
            </Link>
          </div>
        </div>
      </section>

      {/* LIVE SCORE SUMMARY */}
      <section className="mx-auto max-w-5xl px-5">
        <div className="card grid grid-cols-1 gap-8 p-8 md:grid-cols-3 md:items-center">
          <ScoreRing score={finalScores["Lionel Messi"]} color="#5ec9f7" label="Lionel Messi" />
          <div className="text-center">
            <p className="text-xs uppercase tracking-widest text-white/40">Current GOAT Index Leader</p>
            <p className={`mt-2 font-display text-3xl ${winner === "Lionel Messi" ? "text-messi" : "text-ronaldo"}`}>
              {winner}
            </p>
            <p className="mt-3 text-sm text-white/50">
              Score computed from 6 weighted categories: goals, assists, trophies,
              big-game performance, consistency, and individual awards.
            </p>
          </div>
          <ScoreRing score={finalScores["Cristiano Ronaldo"]} color="#ff4757" label="Cristiano Ronaldo" />
        </div>
      </section>

      {/* QUICK STAT SUMMARY */}
      <section className="mx-auto max-w-3xl px-5 py-16">
        <h2 className="mb-6 text-center font-display text-3xl text-white">Career Snapshot</h2>
        <div className="card p-6">
          <StatBar label="Total Goals" messiValue={messi.Total_Goals} ronaldoValue={ronaldo.Total_Goals} />
          <StatBar label="Total Assists" messiValue={messi.Total_Assists} ronaldoValue={ronaldo.Total_Assists} />
          <StatBar label="Total Matches" messiValue={messi.Total_Matches} ronaldoValue={ronaldo.Total_Matches} />
          <StatBar label="Career Trophies" messiValue={messiTrophies} ronaldoValue={ronaldoTrophies} />
        </div>
      </section>

      {/* NAV CARDS */}
      <section className="mx-auto grid max-w-5xl grid-cols-1 gap-5 px-5 pb-24 sm:grid-cols-3">
        <NavCard to="/messi" title="Messi Profile" desc="Career arc, season stats, highlights" accent="messi" />
        <NavCard to="/ronaldo" title="Ronaldo Profile" desc="Career arc, season stats, highlights" accent="ronaldo" />
        <NavCard to="/compare" title="Head-to-Head" desc="Category-by-category breakdown" accent="goat" />
      </section>
    </div>
  );
}

function NavCard({ to, title, desc, accent }) {
  const colorClass = { messi: "text-messi", ronaldo: "text-ronaldo", goat: "text-goat" }[accent];
  return (
    <Link to={to} className="card group p-6 transition hover:-translate-y-1">
      <h3 className={`font-display text-2xl ${colorClass}`}>{title}</h3>
      <p className="mt-2 text-sm text-white/50">{desc}</p>
      <span className="mt-4 inline-block text-sm text-white/40 transition group-hover:text-white">
        Explore →
      </span>
    </Link>
  );
}
