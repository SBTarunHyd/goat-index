import PlayerProfile from "./PlayerProfile";

export default function Ronaldo() {
  return <PlayerProfile playerName="Cristiano Ronaldo" accent="ronaldo" />;
}
