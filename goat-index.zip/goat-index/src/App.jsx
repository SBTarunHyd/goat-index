import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Messi from "./pages/Messi";
import Ronaldo from "./pages/Ronaldo";
import Compare from "./pages/Compare";
import GoatIndexPage from "./pages/GoatIndexPage";

export default function App() {
  return (
    <BrowserRouter>
      <div className="flex min-h-screen flex-col">
        <Navbar />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/messi" element={<Messi />} />
            <Route path="/ronaldo" element={<Ronaldo />} />
            <Route path="/compare" element={<Compare />} />
            <Route path="/goat-index" element={<GoatIndexPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}
