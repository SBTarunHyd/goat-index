import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  Legend,
  Tooltip,
} from "recharts";
import { CATEGORY_LABELS } from "../lib/goatConfig";

export default function RadarComparison({ categoryScores }) {
  const data = Object.entries(categoryScores).map(([key, scores]) => ({
    category: CATEGORY_LABELS[key],
    Messi: Number(scores["Lionel Messi"].toFixed(1)),
    Ronaldo: Number(scores["Cristiano Ronaldo"].toFixed(1)),
  }));

  return (
    <div className="h-[420px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={data} outerRadius="70%">
          <PolarGrid stroke="#ffffff1a" />
          <PolarAngleAxis dataKey="category" tick={{ fill: "#ffffffaa", fontSize: 12 }} />
          <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: "#ffffff55", fontSize: 10 }} />
          <Radar name="Messi" dataKey="Messi" stroke="#5ec9f7" fill="#5ec9f7" fillOpacity={0.35} />
          <Radar name="Ronaldo" dataKey="Ronaldo" stroke="#ff4757" fill="#ff4757" fillOpacity={0.3} />
          <Legend wrapperStyle={{ color: "#fff" }} />
          <Tooltip
            contentStyle={{ background: "#151822", border: "1px solid #ffffff22", borderRadius: 8 }}
            labelStyle={{ color: "#fff" }}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
