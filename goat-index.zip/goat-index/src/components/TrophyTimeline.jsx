import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

// Builds cumulative trophy count per year from a trophies list.
export function buildTrophyTimeline(trophyList) {
  const byYear = new Map();
  trophyList.forEach((t) => {
    const year = parseInt(String(t.Season).slice(0, 4), 10);
    if (!year) return;
    byYear.set(year, (byYear.get(year) || 0) + 1);
  });
  const years = Array.from(byYear.keys()).sort((a, b) => a - b);
  let cumulative = 0;
  return years.map((y) => {
    cumulative += byYear.get(y);
    return { year: y, total: cumulative };
  });
}

export default function TrophyTimeline({ data, color = "#f4c542", label }) {
  return (
    <div className="h-[260px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
          <defs>
            <linearGradient id={`trophy-${label}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.5} />
              <stop offset="100%" stopColor={color} stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#ffffff12" vertical={false} />
          <XAxis dataKey="year" tick={{ fill: "#ffffff77", fontSize: 11 }} />
          <YAxis tick={{ fill: "#ffffff77", fontSize: 11 }} />
          <Tooltip
            contentStyle={{ background: "#151822", border: "1px solid #ffffff22", borderRadius: 8 }}
            labelStyle={{ color: "#fff" }}
          />
          <Area type="monotone" dataKey="total" stroke={color} fill={`url(#trophy-${label})`} strokeWidth={2.5} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
