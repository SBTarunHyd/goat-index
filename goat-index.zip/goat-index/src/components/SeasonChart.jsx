import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

// Aggregates per-competition season rows into one goals/assists total per season.
export function aggregateSeasons(seasonRows) {
  const map = new Map();
  seasonRows.forEach((row) => {
    const key = row.Season;
    if (!map.has(key)) {
      map.set(key, { season: key, goals: 0, assists: 0, age: row.Age });
    }
    const entry = map.get(key);
    entry.goals += row.Goals || 0;
    entry.assists += row.Assists || 0;
  });
  return Array.from(map.values()).sort((a, b) => a.season.localeCompare(b.season));
}

export default function SeasonChart({ data, color = "#5ec9f7" }) {
  return (
    <div className="h-[320px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#ffffff12" vertical={false} />
          <XAxis
            dataKey="season"
            tick={{ fill: "#ffffff77", fontSize: 10 }}
            interval="preserveStartEnd"
            angle={-35}
            textAnchor="end"
            height={50}
          />
          <YAxis tick={{ fill: "#ffffff77", fontSize: 11 }} />
          <Tooltip
            contentStyle={{ background: "#151822", border: "1px solid #ffffff22", borderRadius: 8 }}
            labelStyle={{ color: "#fff" }}
          />
          <Legend wrapperStyle={{ color: "#fff", fontSize: 12 }} />
          <Line type="monotone" dataKey="goals" name="Goals" stroke={color} strokeWidth={2.5} dot={false} />
          <Line
            type="monotone"
            dataKey="assists"
            name="Assists"
            stroke="#ffffff66"
            strokeWidth={2}
            dot={false}
            strokeDasharray="4 3"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
