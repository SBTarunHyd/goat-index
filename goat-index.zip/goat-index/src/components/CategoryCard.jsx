export default function CategoryCard({ title, messiScore, ronaldoScore, weight, description }) {
  const winner = messiScore >= ronaldoScore ? "Messi" : "Ronaldo";
  const winnerColor = winner === "Messi" ? "text-messi" : "text-ronaldo";

  return (
    <div className="card animate-fade-up p-6">
      <div className="mb-3 flex items-start justify-between">
        <div>
          <h3 className="font-display text-2xl tracking-wide text-white">{title}</h3>
          {description && <p className="mt-1 text-sm text-white/50">{description}</p>}
        </div>
        <span className="rounded-full border border-white/10 px-3 py-1 text-xs text-white/50">
          {weight}% weight
        </span>
      </div>

      <div className="mb-2 flex justify-between text-sm font-semibold">
        <span className="text-messi">{messiScore.toFixed(1)}</span>
        <span className="text-ronaldo">{ronaldoScore.toFixed(1)}</span>
      </div>
      <div className="flex h-3 overflow-hidden rounded-full bg-white/5">
        <div className="bg-messi transition-all duration-700" style={{ width: `${messiScore}%` }} />
        <div className="bg-ronaldo transition-all duration-700" style={{ width: `${ronaldoScore}%` }} />
      </div>

      <p className="mt-3 text-xs uppercase tracking-wider text-white/40">
        Category winner: <span className={`font-bold ${winnerColor}`}>{winner}</span>
      </p>
    </div>
  );
}
