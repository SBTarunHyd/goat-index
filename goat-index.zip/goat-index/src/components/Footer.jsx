export default function Footer() {
  return (
    <footer className="mt-24 border-t border-white/5 py-10">
      <div className="mx-auto max-w-7xl px-5 text-sm text-white/40">
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <p>
            <span className="text-goat">GOAT INDEX</span> — a data-driven Messi vs
            Ronaldo comparison platform. Not affiliated with either player, club,
            or federation.
          </p>
          <p>Stats compiled from public career records. Scores are computed, not opinion.</p>
        </div>
      </div>
    </footer>
  );
}
