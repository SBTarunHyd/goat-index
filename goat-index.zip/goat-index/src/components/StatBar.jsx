// Renders a single "vs" bar: left value (Messi) vs right value (Ronaldo)
export default function StatBar({ label, messiValue, ronaldoValue, format = (v) => v, unit = "" }) {
  const max = Math.max(messiValue, ronaldoValue) || 1;
  const messiPct = (messiValue / max) * 100;
  const ronaldoPct = (ronaldoValue / max) * 100;
  const messiWins = messiValue > ronaldoValue;
  const ronaldoWins = ronaldoValue > messiValue;

  return (
    <div className="py-3">
      <div className="mb-1.5 flex items-center justify-between text-sm">
        <span className={`w-20 font-semibold ${messiWins ? "text-messi" : "text-white/70"}`}>
          {format(messiValue)}{unit}
        </span>
        <span className="text-center text-xs uppercase tracking-wider text-white/40">{label}</span>
        <span className={`w-20 text-right font-semibold ${ronaldoWins ? "text-ronaldo" : "text-white/70"}`}>
          {format(ronaldoValue)}{unit}
        </span>
      </div>
      <div className="flex h-2.5 gap-1 overflow-hidden rounded-full bg-white/5">
        <div className="flex flex-1 justify-end">
          <div
            className="h-full rounded-l-full bg-messi transition-all duration-700"
            style={{ width: `${messiPct}%` }}
          />
        </div>
        <div className="flex flex-1 justify-start">
          <div
            className="h-full rounded-r-full bg-ronaldo transition-all duration-700"
            style={{ width: `${ronaldoPct}%` }}
          />
        </div>
      </div>
    </div>
  );
}
