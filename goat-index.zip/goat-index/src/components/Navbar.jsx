import { NavLink } from "react-router-dom";

const links = [
  { to: "/", label: "Home", end: true },
  { to: "/messi", label: "Messi" },
  { to: "/ronaldo", label: "Ronaldo" },
  { to: "/compare", label: "Head-to-Head" },
  { to: "/goat-index", label: "GOAT Index" },
];

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-white/5 bg-ink/80 backdrop-blur-md">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
        <NavLink to="/" className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-goat font-display text-lg text-ink">
            G
          </span>
          <span className="font-display text-xl tracking-wide text-white">
            GOAT<span className="text-goat">INDEX</span>
          </span>
        </NavLink>

        <div className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              className={({ isActive }) =>
                `rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-white/10 text-white"
                    : "text-white/60 hover:text-white"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </div>

        <MobileMenu />
      </nav>
    </header>
  );
}

function MobileMenu() {
  return (
    <details className="relative md:hidden">
      <summary className="list-none rounded-md border border-white/10 px-3 py-2 text-sm text-white/80">
        Menu
      </summary>
      <div className="absolute right-0 mt-2 w-48 rounded-xl border border-white/10 bg-surface p-2 shadow-xl">
        {links.map((l) => (
          <NavLink
            key={l.to}
            to={l.to}
            end={l.end}
            className="block rounded-lg px-3 py-2 text-sm text-white/80 hover:bg-white/5"
          >
            {l.label}
          </NavLink>
        ))}
      </div>
    </details>
  );
}
